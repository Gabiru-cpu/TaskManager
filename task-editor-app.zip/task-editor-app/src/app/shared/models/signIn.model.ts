export class SignInModel {
    userName?: string;
    password?: string
}