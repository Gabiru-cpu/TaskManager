export class NewAssignmentListModel {name?: string; userId?: string}
