export class SignUpModel {
    email?: string;
    userName?: string;
    password?: string;
    passwordConfirm?: string;
}