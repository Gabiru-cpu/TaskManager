export class AssignmentListModel {
    id?: number;
    name?: string;
    userId?: string;
}