export class UserModel {
    userId?:string;
    userName?:string;
}